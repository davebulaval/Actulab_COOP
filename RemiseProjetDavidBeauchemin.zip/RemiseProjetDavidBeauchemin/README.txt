# � propos de l'archive ZIP

#Contient le rapport en format PDF
#Contient l'application (fichier shiny)*
#Fichier du lien WEB vers l'application


#* Note: L'installation de certains packages pourraient �tre n�cessaire 
# pour faire fonctionner l'application.